use egui::panel::Side;
use egui::scroll_area::ScrollBarVisibility;
use egui::style::ScrollStyle;
use egui::{
    Align, CentralPanel, Color32, Context, FontId, Id, LayerId, Order, RichText, SidePanel,
    TextEdit, Ui, Window,
};
use egui_extras::{Column, TableBuilder};
use jgenesis_common::debug::{DebugMemoryView, Endian};
use rfd::FileDialog;
use std::fs::File;
use std::io::BufWriter;
use std::path::Path;
use std::{array, cmp, io};

const MONOSPACE: FontId = FontId::monospace(12.0);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MemoryViewerColumns {
    Byte,
    Word,
    Longword,
}

impl MemoryViewerColumns {
    fn num_columns(self) -> usize {
        match self {
            Self::Byte => 16,
            Self::Word => 8,
            Self::Longword => 4,
        }
    }

    fn column_width(self) -> f32 {
        match self {
            Self::Byte => 15.0,
            Self::Word => 35.0,
            Self::Longword => 80.0,
        }
    }
}

#[derive(Debug, Clone)]
pub struct MemoryViewerState {
    pub window_title: String,
    pub default_file_name: Option<String>,
    pub endian: Endian,
    pub columns: MemoryViewerColumns,
    pub open: bool,
    pub goto_text: String,
    pub goto_address: Option<usize>,
    pub highlight_address: Option<usize>,
    pub set_address_text: String,
    pub table_offset: f32,
    pub table_height: f32,
    pub value_text: String,
    pub set_invalid: bool,
    pub editable: bool,
}

impl MemoryViewerState {
    pub fn new(name: &str, endian: Endian) -> Self {
        Self {
            window_title: format!("{name} Viewer"),
            default_file_name: None,
            endian,
            columns: MemoryViewerColumns::Word,
            open: false,
            goto_text: String::new(),
            goto_address: None,
            highlight_address: None,
            set_address_text: String::new(),
            table_offset: 0.0,
            table_height: 1.0,
            value_text: String::new(),
            set_invalid: false,
            editable: false,
        }
    }

    pub fn with_default_file_name(mut self, name: String) -> Self {
        self.default_file_name = Some(name);
        self
    }

    pub fn with_editable(mut self) -> Self {
        self.editable = true;
        self
    }

    pub fn open_window(&mut self, ctx: &Context) {
        self.open = true;
        ctx.move_to_top(LayerId::new(Order::Middle, Id::new(&self.window_title)));
    }
}

pub fn render(ctx: &Context, memory: &mut dyn DebugMemoryView, state: &mut MemoryViewerState) {
    let memory_len = memory.len();
    if memory_len == 0 {
        return;
    }

    let mut open = state.open;

    Window::new(&state.window_title)
        .open(&mut open)
        .constrain(false)
        .default_pos(crate::rand_window_pos())
        .default_width(600.0)
        .show(ctx, |ui| {
            render_right_panel(memory, state, ui);
            render_central_panel(memory, state, memory_len, ui);
        });

    state.open = open;
}

fn render_right_panel(
    memory: &mut dyn DebugMemoryView,
    state: &mut MemoryViewerState,
    ui: &mut Ui,
) {
    SidePanel::new(Side::Right, format!("{}_right", state.window_title))
        .resizable(false)
        .show_inside(ui, |ui| {
            ui.heading("Go to address");

            ui.horizontal(|ui| {
                let resp = ui.add(
                    TextEdit::singleline(&mut state.goto_text).desired_width(70.0).font(MONOSPACE),
                );
                let enter_pressed =
                    resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));

                let goto_address = ui.button("Go").clicked() || enter_pressed;

                if goto_address && let Ok(address) = usize::from_str_radix(&state.goto_text, 16) {
                    state.goto_address = Some(address);
                }
            });

            if state.editable {
                ui.add_space(20.0);

                ui.heading("Edit memory");

                ui.horizontal(|ui| {
                    ui.label("Address");

                    ui.add(
                        TextEdit::singleline(&mut state.set_address_text)
                            .desired_width(70.0)
                            .font(MONOSPACE),
                    );
                });

                ui.horizontal(|ui| {
                    ui.label("Value");

                    ui.add(
                        TextEdit::singleline(&mut state.value_text)
                            .desired_width(70.0)
                            .font(MONOSPACE),
                    );
                });

                if ui.button("Set byte (8-bit)").clicked() {
                    try_set_byte(memory, state);
                }

                if ui.button("Set word (16-bit)").clicked() {
                    try_set_word(memory, state);
                }

                if ui.button("Set longword (32-bit)").clicked() {
                    try_set_longword(memory, state);
                }

                if state.set_invalid {
                    ui.colored_label(Color32::RED, "Invalid address or value");
                }
            }

            ui.add_space(20.0);

            ui.heading("Column size");
            ui.radio_value(&mut state.columns, MemoryViewerColumns::Byte, "Byte (8-bit)");
            ui.radio_value(&mut state.columns, MemoryViewerColumns::Word, "Word (16-bit)");
            ui.radio_value(&mut state.columns, MemoryViewerColumns::Longword, "Longword (32-bit)");

            ui.add_space(20.0);

            ui.heading("Endianness");
            ui.radio_value(&mut state.endian, Endian::Big, "Big-endian");
            ui.radio_value(&mut state.endian, Endian::Little, "Little-endian");

            ui.add_space(20.0);

            if ui.button("Export to file...").clicked() {
                export_to_file(memory, state);
            }
        });
}

fn render_central_panel(
    memory: &mut dyn DebugMemoryView,
    state: &mut MemoryViewerState,
    memory_len: usize,
    ui: &mut Ui,
) {
    const ROW_HEIGHT: f32 = 15.0;

    let ctx = ui.ctx().clone();

    let highlight_color = crate::highlight_color(ctx.theme());

    CentralPanel::default().show_inside(ui, |ui| {
        ui.spacing_mut().scroll = ScrollStyle { bar_width: 10.0, ..ScrollStyle::solid() };

        let table_rows = memory_len / 16 + usize::from(!memory_len.is_multiple_of(16));
        let address_len = format!("{:X}", memory_len - 1).len();

        let num_columns = state.columns.num_columns();
        let column_width = state.columns.column_width();

        let mut builder = TableBuilder::new(ui)
            .scroll_bar_visibility(ScrollBarVisibility::AlwaysVisible)
            .column(Column::auto().at_least(60.0))
            .columns(Column::auto().at_least(column_width), num_columns)
            .column(Column::remainder().at_least(10.0));

        if let Some(address) = state.goto_address.take() {
            builder =
                builder.scroll_to_row(cmp::min(table_rows - 1, address / 16), Some(Align::Center));
            state.highlight_address = Some(address);
        } else if crate::window_on_top(&ctx, &state.window_title) {
            let keys = crate::scroll_keys_pressed(&ctx);
            if let Some(offset) = keys.relative_scroll_offset(state.table_height) {
                builder = builder.vertical_scroll_offset(state.table_offset + offset);
            }
        }

        let scroll_output = builder.body(|body| {
            body.rows(ROW_HEIGHT, table_rows, |mut row| {
                let address = 16 * row.index();
                let data: [_; 16] = array::from_fn(|i| memory.read(address + i));

                row.col(|ui| {
                    ui.label(RichText::new(fmt_address(address, address_len)).monospace());
                });

                match state.columns {
                    MemoryViewerColumns::Byte => {
                        for (i, byte) in data.into_iter().enumerate() {
                            if address + i < memory_len {
                                row.col(|ui| {
                                    let mut text = RichText::new(format!("{byte:02X}")).monospace();
                                    if state.highlight_address == Some(address + i) {
                                        text = text.color(highlight_color);
                                    }
                                    ui.label(text.monospace());
                                });
                            }
                        }
                    }
                    MemoryViewerColumns::Word => {
                        let to_bytes = match state.endian {
                            Endian::Big => u16::from_be_bytes,
                            Endian::Little => u16::from_le_bytes,
                        };

                        for (i, chunk) in data.chunks_exact(2).enumerate() {
                            if address + 2 * i + 1 < memory_len {
                                let word = to_bytes(chunk.try_into().unwrap());

                                row.col(|ui| {
                                    let mut text = RichText::new(format!("{word:04X}")).monospace();
                                    if state
                                        .highlight_address
                                        .is_some_and(|highlight| highlight & !1 == address + 2 * i)
                                    {
                                        text = text.color(highlight_color);
                                    }
                                    ui.label(text);
                                });
                            }
                        }
                    }
                    MemoryViewerColumns::Longword => {
                        let to_bytes = match state.endian {
                            Endian::Big => u32::from_be_bytes,
                            Endian::Little => u32::from_le_bytes,
                        };

                        for (i, chunk) in data.chunks_exact(4).enumerate() {
                            if address + 4 * i + 3 < memory_len {
                                let longword = to_bytes(chunk.try_into().unwrap());

                                row.col(|ui| {
                                    let mut text =
                                        RichText::new(format!("{longword:08X}")).monospace();
                                    if state
                                        .highlight_address
                                        .is_some_and(|highlight| highlight & !3 == address + 4 * i)
                                    {
                                        text = text.color(highlight_color);
                                    }
                                    ui.label(text);
                                });
                            }
                        }
                    }
                }

                // Hack to make scroll bar not overlap the rightmost data column
                row.col(|_ui| {});
            });
        });
        state.table_offset = scroll_output.state.offset.y;
        state.table_height = scroll_output.inner_rect.height();
    });
}

fn fmt_address(address: usize, len: usize) -> String {
    use std::fmt::Write;

    let mut s = String::with_capacity(len);
    let _ = write!(s, "{address:X}");
    while s.len() < len {
        s.insert(0, '0');
    }

    s
}

fn try_set_byte(memory: &mut dyn DebugMemoryView, state: &mut MemoryViewerState) {
    let Ok(address) = usize::from_str_radix(&state.set_address_text, 16) else {
        state.set_invalid = true;
        return;
    };

    let Ok(byte) = u8::from_str_radix(&state.value_text, 16) else {
        state.set_invalid = true;
        return;
    };

    memory.write(address, byte);

    state.goto_address = Some(address);
    state.set_invalid = false;
}

fn try_set_word(memory: &mut dyn DebugMemoryView, state: &mut MemoryViewerState) {
    let Ok(address) = usize::from_str_radix(&state.set_address_text, 16) else {
        state.set_invalid = true;
        return;
    };

    let Ok(word) = u16::from_str_radix(&state.value_text, 16) else {
        state.set_invalid = true;
        return;
    };

    let [first, second] = match state.endian {
        Endian::Big => word.to_be_bytes(),
        Endian::Little => word.to_le_bytes(),
    };

    memory.write(address & !1, first);
    memory.write(address | 1, second);

    state.goto_address = Some(address);
    state.set_invalid = false;
}

fn try_set_longword(memory: &mut dyn DebugMemoryView, state: &mut MemoryViewerState) {
    let Ok(address) = usize::from_str_radix(&state.set_address_text, 16) else {
        state.set_invalid = true;
        return;
    };

    let Ok(longword) = u32::from_str_radix(&state.value_text, 16) else {
        state.set_invalid = true;
        return;
    };

    let bytes = match state.endian {
        Endian::Big => longword.to_be_bytes(),
        Endian::Little => longword.to_le_bytes(),
    };

    for (i, byte) in bytes.into_iter().enumerate() {
        memory.write((address & !3) | i, byte);
    }

    state.goto_address = Some(address);
    state.set_invalid = false;
}

fn export_to_file(memory: &mut dyn DebugMemoryView, state: &MemoryViewerState) {
    let file_name = state.default_file_name.clone().unwrap_or("memory.bin".into());

    let Some(path) =
        FileDialog::new().set_file_name(file_name).add_filter("bin", &["bin"]).save_file()
    else {
        return;
    };

    if let Err(err) = try_export_to_file(&path, memory) {
        log::error!("Error saving to path '{}': {err}", path.display());
    }
}

fn try_export_to_file(path: &Path, memory: &mut dyn DebugMemoryView) -> io::Result<()> {
    use std::io::Write;

    let file = File::create(path)?;
    let mut writer = BufWriter::new(file);

    let len = memory.len();
    for address in 0..len {
        writer.write_all(&[memory.read(address)])?;
    }

    Ok(())
}
